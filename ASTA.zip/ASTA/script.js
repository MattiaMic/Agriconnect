const currentBid = document.getElementById('current-bid');
const bidInput = document.getElementById('bid-input');
const bidButton = document.getElementById('bid-button');
const timeRemaining = document.getElementById('time-remaining');

let currentHighestBid = 0;
let auctionEndTime = new Date(new Date().getTime() + 10 * 60 * 1000 * 24); // 10 minutes from now

bidButton.addEventListener('click', () => {
 const bidAmount = parseFloat(bidInput.value);

 if (bidAmount > currentHighestBid) {
    currentHighestBid = bidAmount;
    currentBid.textContent = `$${currentHighestBid}`;
    bidInput.value = '';
 }
});

setInterval(() => {
 const now = new Date();
 const timeLeft = auctionEndTime - now;

 if (timeLeft <= 0) {
    alert('Auction ended');
    return;
 }

 const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
 const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

 timeRemaining.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
}, 1000);